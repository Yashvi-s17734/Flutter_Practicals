import 'package:flutter/material.dart';
void main() {
  runApp(MaterialApp(
      home: Scaffold(
          appBar: AppBar(
            title: Text("Practical 3"),
          ),
          body: Column(children: [
            Icon(Icons.ac_unit_outlined),
            Container(
              width: 200,
              height: 200,
              color: Colors.blue,
              margin: EdgeInsets.all(10),
              padding: EdgeInsets.symmetric(vertical: 60, horizontal: 50),
              child: Text("Yashvi",style: TextStyle(color: Colors.white),),
            ),
          ]
        )
     )
  )
);
}
